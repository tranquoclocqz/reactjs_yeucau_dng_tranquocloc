export interface IResponse {
  data: {
    message?: string;
    data?: any;
    status?: number;
  }
}
