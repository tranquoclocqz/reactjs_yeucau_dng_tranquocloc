import _axios from 'axios';


const url = process.env.API_LINK;
const axios = _axios.create({
    baseURL: url,
});

// Request interceptor for API calls
axios.interceptors.request.use(
    async (config) => {
        // const accessToken = getAccessTokenLocalStorage();
        // config.headers = {
        //   ...config.headers,
        //   Authorization: `Bearer ${accessToken}`,
        // };
        return config;
    },
    (error) => {
        Promise.reject(error);
    }
);

// Response interceptor for API calls
axios.interceptors.response.use(
    (response) => {
        return response.data;
    },
    async function (error) {
        const originalRequest = error.config;
        if (error.response.status === 403 && !originalRequest._retry) {
            originalRequest._retry = true;
            //   const token = getTokenLocalStorage();
            //   const { data } = await refreshTokenService({ refreshToken: token || '' });
            //   setAccessTokenLocalStorage(data.accessToken);

            //   axios.defaults.headers.common['Authorization'] =
            //     'Bearer ' + data.accessToken;
            //   return axios(originalRequest);
        }
        return Promise.reject(error);
    }
);
export default axios;
