import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import { ILogin } from 'typings';
import * as yup from 'yup';

import Checkbox from 'designs/Checkbox';
import Input from 'designs/Input';

interface ILoginProps {}
const schema = yup
  .object()
  .shape<{ [key in keyof ILogin]: any }>({
    email: yup.string().required('This field not empty !'),
    password: yup.string().required('This field not empty !'),
  })
  .required();

const Login: React.FC<ILoginProps> = (props) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ILogin>({
    resolver: yupResolver(schema),
  });
  const onSubmit = (data: ILogin) => {
    console.log('data', data);
  };
  return (
    <div className="flex flex-col justify-center min-h-full py-12 sm:p-2">
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="p-2 bg-white shadow sm:rounded-lg sm:px-3">
          <h1 className="w-full font-bold text-center text-32">Sign in</h1>
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="space-y-3"
            action="#"
            method="POST">
            <Input
              label="Email"
              required={true}
              errorMessage={errors.email?.message}
              name="email"
              register={register}
            />

            <Input
              label="Password"
              required={true}
              errorMessage={errors.password?.message}
              name="password"
              register={register}
            />

            <div className="flex items-center justify-between">
              <Checkbox
                label="Remember me"
                name="rememberPassword"
                register={register}
              />
            </div>

            <div>
              <button
                type="submit"
                className="flex justify-center w-full px-2 py-1 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                Sign in
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
