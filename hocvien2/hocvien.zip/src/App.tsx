import React from 'react';

import Route from 'routes';

function App() {
  return <Route />;
}

export default App;
