import { UseFormRegister } from 'react-hook-form';

interface IInputProps {
  required: boolean;
  errorMessage: string;
  className?: string;
  label: string;
  name: string;
  placeholder?: string;
  register: UseFormRegister<any>;
}

const Input: React.FC<IInputProps> = (props) => {
  const {
    register,
    placeholder,
    name,
    label,
    required,
    errorMessage,
    className,
  } = props;
  return (
    <div className={className}>
      {label && (
        <label htmlFor="email" className="block text-sm text-gray-700">
          {label}
          <span className="ml-0.5 text-red-500">{required && '*'}</span>
        </label>
      )}
      <div className="relative mt-1">
        <input
          autoComplete="off"
          placeholder={placeholder}
          className={`block w-full px-2 py-1 placeholder-gray-400 border border-solid rounded-md shadow-sm appearance-none border-grey-dark focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${
            errorMessage && '!border-red-600'
          }`}
          {...register(name)}
        />
        {errorMessage && (
          <p className="mt-0.5 absolute left-0 -bottom-2 text-red-500 text-12">
            {errorMessage}
          </p>
        )}
      </div>
    </div>
  );
};

export default Input;
