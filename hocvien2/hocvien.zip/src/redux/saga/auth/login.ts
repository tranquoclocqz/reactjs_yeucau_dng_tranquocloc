import { call, put } from 'redux-saga/effects';

import {
    loginSuccess
} from 'redux/actions/auth';
import { setLoading } from 'redux/actions/common';

import {
    loginService

} from 'services/auth';

import { IResponse } from 'typings';

export function* login(payload: any) {
    const variables = payload.payload;
    yield put(setLoading(true));
    try {
        const response: IResponse = yield call(loginService, variables);
        yield put(setLoading(false));
        const { data } = response.data || {}
        if (data) {
            yield put(loginSuccess(data))
        }
    } catch (error) {
        yield put(setLoading(false));
        console.log(error);
    }
}