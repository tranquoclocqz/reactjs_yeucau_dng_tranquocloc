import produce from "immer"
import * as types from "redux/types/auth"
import { AnyAction } from "redux";

interface AuthState {

}

const initialState: AuthState = {

}

const reducer = (state = initialState, action: AnyAction) =>
    produce(state, (draft) => {
        switch (action.type) {
            case types.LOGIN_SUCCESS:
                //do something when login success
                break;
        }
    });

export default reducer;