import React from 'react';

export type IIconSVGProps = React.SVGProps<SVGSVGElement>;
