const StaffTechnical = () => {
  return <div>technical</div>;
};
export default StaffTechnical;
