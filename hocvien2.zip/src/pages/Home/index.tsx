interface IHomeProps {}

const Home: React.FC<IHomeProps> = (props) => {
  return <div>Home</div>;
};

export default Home;
